
	<div class="menu">
		<ul class="menu_list">
			<li><a href="blog.php">Przeglądaj</a> </li>
			<li><a href="nowy.php">Załóż blog</a> </li>
			<li><a href="wpis.php">Dodaj wpis</a> </li>
		</ul>
	</div>